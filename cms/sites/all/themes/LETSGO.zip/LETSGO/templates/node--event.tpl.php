<div>
    <div class="left" style="background-color: rebeccapurple">
        links
    </div>
    <div class="right">
        rechts
    </div>
</div>